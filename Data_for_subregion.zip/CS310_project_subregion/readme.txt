Number of rows: 63
Number of columns: 63

Format: 32-bit floating point binary 
Byte order: PC (little endian)

Bounding box of region: (62,204) (upper left corner) - (124,266) (lower right corner)

